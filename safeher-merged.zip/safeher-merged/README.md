# 🌸 SafeHer — Full Stack Platform (Frontend + Backend)

Complete Women Safety & NGO Support Platform with real-time features.

---

## 📁 Project Structure

```
safeher-merged/
├── frontend/
│   ├── index.html         ← Main SPA (all 8 pages)
│   └── js/
│       └── api.js         ← Backend integration layer
│
└── backend/               ← Node.js + Express + MongoDB
    ├── src/
    │   ├── server.js
    │   ├── seed.js
    │   ├── models/
    │   ├── controllers/
    │   ├── routes/
    │   ├── middleware/
    │   └── socket/
    ├── config/
    │   └── db.js
    ├── package.json
    ├── .env.example
    └── README.md
```

---

## 🚀 Quick Start

### Step 1 — Start the Backend

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI

# Seed the database
npm run seed

# Start the server
npm run dev
```

Server runs at: **http://localhost:5000**

### Step 2 — Open the Frontend

Open `frontend/index.html` directly in your browser.

Or serve it locally:
```bash
cd frontend
npx serve .
# Visit http://localhost:3000
```

---

## 🔑 Test Credentials (after seeding)

| Role       | Email                    | Password      |
|------------|--------------------------|---------------|
| Admin      | admin@safeher.org        | Admin@123456  |
| NGO Admin  | ngo@nirbhayasena.org     | Ngo@123456    |
| User       | user@safeher.org         | User@123456   |

---

## ✨ Features

### Frontend (index.html)
- **8 Pages:** Home, NGO Directory, NGO Detail, Help Request, Report Incident, Nearby Map, Resources, Dashboard
- **SOS Button** with GPS + real-time Socket.IO alert to admins
- **Real-time Leaflet map** with GPS location detection
- **Auth modals** — Login / Register with JWT
- **Notification bell** — real-time push notifications via Socket.IO
- **Graceful offline mode** — falls back to localStorage when backend is unavailable

### Backend (Node.js + Express + MongoDB)
- **JWT Auth** with roles: user / ngo_admin / admin
- **Rate limiting** — 100 req/15min global, 10 req/15min on auth
- **Socket.IO** — real-time SOS alerts and push notifications
- **File uploads** — Multer with type/size validation
- **Geo queries** — NGOs near user's lat/lng ($near MongoDB)
- **Admin API** — stats, user management, request assignment

### API Endpoints
| Service | Base Path |
|---------|-----------|
| Auth | `/api/auth` |
| NGOs | `/api/ngos` |
| Help Requests | `/api/help-requests` |
| Incident Reports | `/api/reports` |
| Notifications | `/api/notifications` |
| Admin | `/api/admin` |

---

## 🌐 Deployment

### Frontend → Netlify / Vercel / GitHub Pages
- Upload the `frontend/` folder
- Update `API_BASE` in `frontend/js/api.js` to your production backend URL

### Backend → Railway / Render
- Connect your GitHub repo
- Set environment variables from `.env.example`
- Use MongoDB Atlas

---

## 🛡️ Security
- Passwords hashed with bcrypt (cost 12)
- JWT with configurable expiry
- Helmet.js security headers
- CORS restricted to frontend origin
- Role-based access control
- File upload validation
