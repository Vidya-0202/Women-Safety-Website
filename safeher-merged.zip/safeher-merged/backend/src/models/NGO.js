const mongoose = require('mongoose');

const ngoSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'NGO name is required'],
      trim: true,
    },
    city: { type: String, required: true },
    state: { type: String, required: true },
    address: { type: String, required: true },
    phone: { type: String, required: true },
    email: { type: String, required: true, lowercase: true },
    about: { type: String, required: true },
    hours: { type: String, default: 'Mon–Sat: 9am–6pm' },
    services: [
      {
        type: String,
        enum: ['Shelter', 'Legal Aid', 'Counseling', 'Medical', 'Child Care'],
      },
    ],
    tags: [String],
    icon: { type: String, default: '🏢' },
    color: { type: String, default: '#e8d5f5' },
    isVerified: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    rating: { type: Number, default: 0, min: 0, max: 5 },
    totalRatings: { type: Number, default: 0 },
    casesHandled: { type: Number, default: 0 },
    location: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point',
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        default: [0, 0],
      },
    },
  },
  { timestamps: true }
);

// Geo index for nearby queries
ngoSchema.index({ location: '2dsphere' });

module.exports = mongoose.model('NGO', ngoSchema);
