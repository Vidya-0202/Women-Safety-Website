const mongoose = require('mongoose');

const helpRequestSchema = new mongoose.Schema(
  {
    // Who submitted
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null, // null = anonymous
    },
    name: { type: String, default: 'Anonymous' },
    contact: { type: String, required: true },

    // Request details
    type: {
      type: String,
      required: true,
      enum: [
        'Domestic Violence / Abuse',
        'Shelter / Accommodation',
        'Legal Assistance',
        'Mental Health / Counseling',
        'Medical Assistance',
        'Child Safety',
        'Trafficking / Exploitation',
        'Other Emergency',
      ],
    },
    description: { type: String, required: true },
    location: { type: String, required: true },
    coordinates: {
      lat: Number,
      lng: Number,
    },
    preferredContactTime: {
      type: String,
      default: 'Any time',
    },

    // Assignment
    assignedNGO: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'NGO',
      default: null,
    },
    assignedTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },

    // Status tracking
    status: {
      type: String,
      enum: ['Pending', 'Assigned', 'Active', 'Resolved', 'Closed'],
      default: 'Pending',
    },
    priority: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      default: 'Medium',
    },

    // Notes from NGO
    notes: [
      {
        text: String,
        addedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        addedAt: { type: Date, default: Date.now },
      },
    ],

    resolvedAt: Date,
  },
  { timestamps: true }
);

module.exports = mongoose.model('HelpRequest', helpRequestSchema);
