const mongoose = require('mongoose');

const incidentReportSchema = new mongoose.Schema(
  {
    reporter: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    contactInfo: { type: String, default: '' },

    type: {
      type: String,
      required: true,
      enum: [
        'Harassment / Eve Teasing',
        'Domestic Violence',
        'Stalking',
        'Unsafe Public Space',
        'Online Harassment',
        'Other',
      ],
    },
    incidentDate: { type: Date, required: true },
    location: { type: String, required: true },
    coordinates: {
      lat: Number,
      lng: Number,
    },
    description: { type: String, required: true },

    // Evidence files (stored paths)
    evidence: [
      {
        filename: String,
        originalName: String,
        mimetype: String,
        size: Number,
        path: String,
        uploadedAt: { type: Date, default: Date.now },
      },
    ],

    status: {
      type: String,
      enum: ['Under Review', 'Investigating', 'Forwarded to Authorities', 'Closed'],
      default: 'Under Review',
    },

    // Admin notes
    adminNotes: [
      {
        text: String,
        addedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        addedAt: { type: Date, default: Date.now },
      },
    ],

    isAnonymous: { type: Boolean, default: true },
    forwardedToPolice: { type: Boolean, default: false },
    forwardedAt: Date,
  },
  { timestamps: true }
);

module.exports = mongoose.model('IncidentReport', incidentReportSchema);
