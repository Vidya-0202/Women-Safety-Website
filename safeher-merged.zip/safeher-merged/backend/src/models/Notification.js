const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema(
  {
    recipient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    type: {
      type: String,
      enum: [
        'help_request_received',   // sent to NGO admin
        'help_request_assigned',   // sent to user
        'help_request_updated',    // status change
        'help_request_resolved',
        'report_received',
        'report_updated',
        'sos_alert',
        'system',
      ],
      required: true,
    },
    title: { type: String, required: true },
    message: { type: String, required: true },
    link: { type: String, default: '' }, // frontend route to navigate to
    isRead: { type: Boolean, default: false },
    // Reference to related doc
    refModel: { type: String, enum: ['HelpRequest', 'IncidentReport', null], default: null },
    refId: { type: mongoose.Schema.Types.ObjectId, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Notification', notificationSchema);
