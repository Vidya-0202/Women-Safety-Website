const express = require('express');
const router = express.Router();
const {
  getAllNGOs,
  getNearbyNGOs,
  getNGOById,
  createNGO,
  updateNGO,
  deleteNGO,
} = require('../controllers/ngoController');
const { protect, authorise } = require('../middleware/auth');

// Public
router.get('/', getAllNGOs);
router.get('/nearby', getNearbyNGOs);
router.get('/:id', getNGOById);

// Admin only
router.post('/', protect, authorise('admin'), createNGO);
router.put('/:id', protect, authorise('admin', 'ngo_admin'), updateNGO);
router.delete('/:id', protect, authorise('admin'), deleteNGO);

module.exports = router;
