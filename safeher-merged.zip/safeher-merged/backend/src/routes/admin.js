const express = require('express');
const router = express.Router();
const {
  getDashboardStats,
  getAllUsers,
  updateUserRole,
  toggleUserActive,
  getRequestsSummary,
} = require('../controllers/adminController');
const { protect, authorise } = require('../middleware/auth');

// All admin routes require admin role
router.use(protect, authorise('admin'));

router.get('/stats', getDashboardStats);
router.get('/users', getAllUsers);
router.put('/users/:id/role', updateUserRole);
router.put('/users/:id/toggle', toggleUserActive);
router.get('/requests/summary', getRequestsSummary);

module.exports = router;
