const express = require('express');
const router = express.Router();
const {
  createHelpRequest,
  getAllRequests,
  getMyRequests,
  getRequestById,
  updateRequest,
  deleteRequest,
} = require('../controllers/helpRequestController');
const { protect, authorise, optionalAuth } = require('../middleware/auth');

// Anyone can submit (optionalAuth attaches user if logged in)
router.post('/', optionalAuth, createHelpRequest);

// Logged-in user — own requests
router.get('/my', protect, getMyRequests);

// Admin / NGO admin — all requests
router.get('/', protect, authorise('admin', 'ngo_admin'), getAllRequests);

// Single request
router.get('/:id', protect, getRequestById);
router.put('/:id', protect, authorise('admin', 'ngo_admin'), updateRequest);
router.delete('/:id', protect, authorise('admin'), deleteRequest);

module.exports = router;
