const express = require('express');
const router = express.Router();
const {
  createReport,
  getAllReports,
  getMyReports,
  getReportById,
  updateReport,
} = require('../controllers/reportController');
const { protect, authorise, optionalAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Anyone can file a report; attach files with key "evidence"
router.post('/', optionalAuth, upload.array('evidence', 5), createReport);

// Own reports
router.get('/my', protect, getMyReports);

// Admin / NGO admin
router.get('/', protect, authorise('admin', 'ngo_admin'), getAllReports);

// Single report
router.get('/:id', protect, getReportById);
router.put('/:id', protect, authorise('admin', 'ngo_admin'), updateReport);

module.exports = router;
