const Notification = require('../models/Notification');

/**
 * Create a notification and emit it via Socket.IO if the recipient is online.
 * @param {object} io         - Socket.IO server instance
 * @param {object} data       - { recipient, type, title, message, link, refModel, refId }
 */
const createNotification = async (io, data) => {
  try {
    const notification = await Notification.create(data);

    // Emit real-time event to recipient's personal room
    if (io) {
      io.to(`user:${data.recipient}`).emit('notification', {
        _id: notification._id,
        type: notification.type,
        title: notification.title,
        message: notification.message,
        link: notification.link,
        isRead: false,
        createdAt: notification.createdAt,
      });
    }

    return notification;
  } catch (err) {
    console.error('Notification error:', err.message);
  }
};

module.exports = { createNotification };
