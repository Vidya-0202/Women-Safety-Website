require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('./models/User');
const NGO = require('./models/NGO');

const ngos = [
  {
    name: 'Shakti Foundation', city: 'Mumbai', state: 'Maharashtra',
    address: '14, MG Road, Bandra West, Mumbai – 400050',
    phone: '+91 22 1234 5678', email: 'help@shaktifoundation.org',
    about: 'Shakti Foundation has been serving women in distress since 2001, providing comprehensive support including emergency shelter, legal assistance, and trauma counseling.',
    hours: '24/7 Emergency Line Available',
    services: ['Shelter', 'Legal Aid', 'Counseling'],
    tags: ['shelter', 'legal', 'counseling'],
    icon: '🌺', color: '#f8d7e3', rating: 4.8, casesHandled: 2400, isVerified: true,
    location: { type: 'Point', coordinates: [72.8346, 19.0596] },
  },
  {
    name: 'Prerna Welfare Society', city: 'Delhi', state: 'Delhi',
    address: '27, Lajpat Nagar II, New Delhi – 110024',
    phone: '+91 11 9876 5432', email: 'prerna@welfare.org',
    about: 'Prerna Welfare Society provides free legal aid, medical support, and counseling services to women who are victims of domestic violence and harassment.',
    hours: 'Mon – Sat: 9am – 7pm',
    services: ['Legal Aid', 'Medical', 'Counseling'],
    tags: ['legal', 'medical', 'counseling'],
    icon: '⚖️', color: '#e8d5f5', rating: 4.7, casesHandled: 1800, isVerified: true,
    location: { type: 'Point', coordinates: [77.2090, 28.6139] },
  },
  {
    name: 'Asha Kiran Trust', city: 'Bangalore', state: 'Karnataka',
    address: '88, Koramangala 4th Block, Bangalore – 560034',
    phone: '+91 80 5555 6666', email: 'asha@kirantrust.org',
    about: 'Asha Kiran Trust focuses on supporting women with children, offering safe shelter, childcare facilities, and rehabilitation programs to rebuild lives.',
    hours: '24/7 Helpline',
    services: ['Shelter', 'Child Care', 'Counseling'],
    tags: ['shelter', 'child', 'counseling'],
    icon: '🏠', color: '#d5e8f5', rating: 4.9, casesHandled: 3100, isVerified: true,
    location: { type: 'Point', coordinates: [77.6245, 12.9716] },
  },
  {
    name: 'Nirbhaya Sena', city: 'Pune', state: 'Maharashtra',
    address: '12, FC Road, Shivajinagar, Pune – 411004',
    phone: '+91 20 7777 8888', email: 'support@nirbhayasena.org',
    about: 'Nirbhaya Sena empowers survivors through legal battles, medical care, and psychological rehabilitation. They also run community awareness programs.',
    hours: 'Mon – Sun: 8am – 9pm',
    services: ['Legal Aid', 'Counseling', 'Medical'],
    tags: ['legal', 'counseling', 'medical'],
    icon: '💪', color: '#f5e8d5', rating: 4.6, casesHandled: 1200, isVerified: true,
    location: { type: 'Point', coordinates: [73.8567, 18.5204] },
  },
  {
    name: 'Mahila Suraksha Kendra', city: 'Chennai', state: 'Tamil Nadu',
    address: '45, Anna Salai, T. Nagar, Chennai – 600017',
    phone: '+91 44 3333 4444', email: 'msk@mahilasuraksha.org',
    about: 'MSK is one of Tamil Nadu\'s largest women\'s support organizations, offering a full spectrum of services from immediate shelter to long-term rehabilitation.',
    hours: '24/7 Emergency, Office hours 9am–6pm',
    services: ['Shelter', 'Legal Aid', 'Medical', 'Child Care'],
    tags: ['shelter', 'legal', 'medical', 'child'],
    icon: '🌿', color: '#e8f5e8', rating: 4.9, casesHandled: 4500, isVerified: true,
    location: { type: 'Point', coordinates: [80.2707, 13.0827] },
  },
];

const seedDB = async () => {
  try {
    await connectDB();
    console.log('🌱 Seeding database...');

    // Clear existing data
    await User.deleteMany({});
    await NGO.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Create NGOs
    const createdNGOs = await NGO.insertMany(ngos);
    console.log(`✅ Created ${createdNGOs.length} NGOs`);

    // Create super admin
    const admin = await User.create({
      name: 'SafeHer Admin',
      email: process.env.ADMIN_EMAIL || 'admin@safeher.org',
      password: process.env.ADMIN_PASSWORD || 'Admin@123456',
      role: 'admin',
      isVerified: true,
      phone: '+91 1800 000 000',
    });
    console.log(`✅ Created admin user: ${admin.email}`);

    // Create NGO admin for Nirbhaya Sena (Pune)
    const punNGO = createdNGOs.find(n => n.name === 'Nirbhaya Sena');
    await User.create({
      name: 'Pune NGO Admin',
      email: 'ngo@nirbhayasena.org',
      password: 'Ngo@123456',
      role: 'ngo_admin',
      managedNGO: punNGO._id,
      isVerified: true,
    });
    console.log('✅ Created NGO admin user: ngo@nirbhayasena.org');

    // Create sample user
    await User.create({
      name: 'Test User',
      email: 'user@safeher.org',
      password: 'User@123456',
      role: 'user',
      phone: '+91 98765 00000',
      isVerified: true,
      emergencyContacts: [
        { name: 'Mom', phone: '+91 98765 43210', relation: 'Mother' },
      ],
    });
    console.log('✅ Created test user: user@safeher.org');

    console.log('\n🎉 Database seeded successfully!\n');
    console.log('📋 Test Credentials:');
    console.log('   Admin     → admin@safeher.org   / Admin@123456');
    console.log('   NGO Admin → ngo@nirbhayasena.org / Ngo@123456');
    console.log('   User      → user@safeher.org    / User@123456');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
};

seedDB();
