require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const connectDB = require('../config/db');
const errorHandler = require('./middleware/errorHandler');

// Controllers that need the io instance
const helpRequestCtrl = require('./controllers/helpRequestController');
const reportCtrl = require('./controllers/reportController');

// ── Connect Database ──────────────────────────────────
connectDB();

const app = express();
const server = http.createServer(app);

// ── Socket.IO Setup ───────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
    credentials: true,
  },
});

// Pass io instance to controllers that need it
helpRequestCtrl.setIO(io);
reportCtrl.setIO(io);

// ── Socket.IO Auth & Rooms ────────────────────────────
const jwt = require('jsonwebtoken');
const User = require('./models/User');

io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(); // allow anonymous connection
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');
    if (user) {
      socket.user = user;
      socket.join(`user:${user._id}`); // personal room
      if (user.role === 'admin') socket.join('admins'); // admin broadcast room
      if (user.role === 'ngo_admin') socket.join(`ngo:${user.managedNGO}`);
    }
    next();
  } catch {
    next(); // don't block on bad token
  }
});

io.on('connection', (socket) => {
  if (socket.user) {
    console.log(`🔌 Socket connected: ${socket.user.name} (${socket.user.role})`);
  }

  // SOS broadcast — emit to all admins immediately
  socket.on('sos_alert', async (data) => {
    io.to('admins').emit('sos_alert', {
      userId: socket.user?._id,
      userName: socket.user?.name || 'Anonymous',
      ...data,
      timestamp: new Date(),
    });
    console.log(`🆘 SOS ALERT from ${socket.user?.name || 'anonymous'}`);
  });

  socket.on('disconnect', () => {
    if (socket.user) console.log(`🔌 Socket disconnected: ${socket.user.name}`);
  });
});

// ── Core Middleware ────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// ── Rate Limiting ──────────────────────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: { success: false, message: 'Too many requests, please try again later.' },
});
app.use('/api', limiter);

// Stricter limit on auth routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, message: 'Too many auth attempts, please try again later.' },
});
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);

// ── Static Uploads ─────────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, '..', process.env.UPLOAD_PATH || 'uploads')));

// ── API Routes ─────────────────────────────────────────
app.use('/api/auth', require('./routes/auth'));
app.use('/api/ngos', require('./routes/ngos'));
app.use('/api/help-requests', require('./routes/helpRequests'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/admin', require('./routes/admin'));

// ── Health Check ───────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: '💚 SafeHer API is running',
    environment: process.env.NODE_ENV,
    timestamp: new Date().toISOString(),
  });
});

// ── 404 Handler ────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

// ── Global Error Handler ───────────────────────────────
app.use(errorHandler);

// ── Start Server ───────────────────────────────────────
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`\n🌸 SafeHer Backend running on port ${PORT}`);
  console.log(`📡 Mode: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 Health: http://localhost:${PORT}/api/health\n`);
});

module.exports = { app, io };
