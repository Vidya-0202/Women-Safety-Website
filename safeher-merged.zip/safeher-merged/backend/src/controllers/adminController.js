const User = require('../models/User');
const NGO = require('../models/NGO');
const HelpRequest = require('../models/HelpRequest');
const IncidentReport = require('../models/IncidentReport');

// ── GET /api/admin/stats ──────────────────────────────
exports.getDashboardStats = async (req, res, next) => {
  try {
    const [totalUsers, totalNGOs, totalRequests, totalReports,
           pendingRequests, activeRequests, unreviewedReports] = await Promise.all([
      User.countDocuments({ role: 'user', isActive: true }),
      NGO.countDocuments({ isActive: true }),
      HelpRequest.countDocuments(),
      IncidentReport.countDocuments(),
      HelpRequest.countDocuments({ status: 'Pending' }),
      HelpRequest.countDocuments({ status: 'Active' }),
      IncidentReport.countDocuments({ status: 'Under Review' }),
    ]);

    // Recent 7 days requests
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const recentRequests = await HelpRequest.countDocuments({ createdAt: { $gte: weekAgo } });

    res.status(200).json({
      success: true,
      data: {
        totalUsers, totalNGOs, totalRequests, totalReports,
        pendingRequests, activeRequests, unreviewedReports, recentRequests,
      },
    });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/admin/users ──────────────────────────────
exports.getAllUsers = async (req, res, next) => {
  try {
    const { role, page = 1, limit = 20, search } = req.query;
    const filter = {};
    if (role) filter.role = role;
    if (search) filter.$or = [
      { name: new RegExp(search, 'i') },
      { email: new RegExp(search, 'i') },
    ];
    const total = await User.countDocuments(filter);
    const users = await User.find(filter)
      .select('-password')
      .populate('managedNGO', 'name city')
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    res.status(200).json({ success: true, total, data: users });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/admin/users/:id/role ─────────────────────
exports.updateUserRole = async (req, res, next) => {
  try {
    const { role, managedNGO } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role, managedNGO: managedNGO || null },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.status(200).json({ success: true, data: user });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/admin/users/:id/toggle ──────────────────
exports.toggleUserActive = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    user.isActive = !user.isActive;
    await user.save({ validateBeforeSave: false });
    res.status(200).json({ success: true, data: { isActive: user.isActive } });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/admin/requests/summary ──────────────────
exports.getRequestsSummary = async (req, res, next) => {
  try {
    const byStatus = await HelpRequest.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]);
    const byType = await HelpRequest.aggregate([
      { $group: { _id: '$type', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);
    res.status(200).json({ success: true, data: { byStatus, byType } });
  } catch (err) {
    next(err);
  }
};
