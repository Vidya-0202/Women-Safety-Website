const HelpRequest = require('../models/HelpRequest');
const User = require('../models/User');
const { createNotification } = require('../socket/notifications');

let _io = null;
exports.setIO = (io) => { _io = io; };

// ── POST /api/help-requests ───────────────────────────
exports.createHelpRequest = async (req, res, next) => {
  try {
    const { name, contact, type, description, location, coordinates, preferredContactTime } = req.body;

    const request = await HelpRequest.create({
      user: req.user?._id || null,
      name: name || (req.user?.name) || 'Anonymous',
      contact,
      type,
      description,
      location,
      coordinates,
      preferredContactTime,
    });

    // Notify all admin users
    const admins = await User.find({ role: { $in: ['admin', 'ngo_admin'] }, isActive: true });
    for (const admin of admins) {
      await createNotification(_io, {
        recipient: admin._id,
        type: 'help_request_received',
        title: '🆘 New Help Request',
        message: `A new ${type} request has been submitted from ${location}.`,
        link: `/admin/requests/${request._id}`,
        refModel: 'HelpRequest',
        refId: request._id,
      });
    }

    res.status(201).json({ success: true, data: request });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/help-requests  (admin/ngo_admin) ─────────
exports.getAllRequests = async (req, res, next) => {
  try {
    const { status, priority, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (priority) filter.priority = priority;

    // NGO admins only see requests assigned to their NGO
    if (req.user.role === 'ngo_admin') {
      filter.assignedNGO = req.user.managedNGO;
    }

    const total = await HelpRequest.countDocuments(filter);
    const requests = await HelpRequest.find(filter)
      .populate('assignedNGO', 'name city')
      .populate('assignedTo', 'name email')
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, total, data: requests });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/help-requests/my  (user's own) ───────────
exports.getMyRequests = async (req, res, next) => {
  try {
    const requests = await HelpRequest.find({ user: req.user._id })
      .populate('assignedNGO', 'name phone city')
      .sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: requests });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/help-requests/:id ───────────────────────
exports.getRequestById = async (req, res, next) => {
  try {
    const request = await HelpRequest.findById(req.params.id)
      .populate('assignedNGO', 'name phone email city')
      .populate('assignedTo', 'name email')
      .populate('notes.addedBy', 'name');

    if (!request) return res.status(404).json({ success: false, message: 'Request not found' });

    // Users can only see their own
    if (req.user.role === 'user' && request.user?.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorised' });
    }

    res.status(200).json({ success: true, data: request });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/help-requests/:id  (admin/ngo_admin) ────
exports.updateRequest = async (req, res, next) => {
  try {
    const { status, priority, assignedNGO, assignedTo, note } = req.body;
    const request = await HelpRequest.findById(req.params.id);
    if (!request) return res.status(404).json({ success: false, message: 'Request not found' });

    if (status) request.status = status;
    if (priority) request.priority = priority;
    if (assignedNGO) request.assignedNGO = assignedNGO;
    if (assignedTo) request.assignedTo = assignedTo;
    if (note) request.notes.push({ text: note, addedBy: req.user._id });
    if (status === 'Resolved') request.resolvedAt = new Date();

    await request.save();

    // Notify the user who submitted
    if (request.user) {
      await createNotification(_io, {
        recipient: request.user,
        type: 'help_request_updated',
        title: '📋 Help Request Updated',
        message: `Your help request status changed to: ${request.status}.`,
        link: `/dashboard`,
        refModel: 'HelpRequest',
        refId: request._id,
      });
    }

    res.status(200).json({ success: true, data: request });
  } catch (err) {
    next(err);
  }
};

// ── DELETE /api/help-requests/:id  (admin only) ──────
exports.deleteRequest = async (req, res, next) => {
  try {
    await HelpRequest.findByIdAndDelete(req.params.id);
    res.status(200).json({ success: true, message: 'Request deleted' });
  } catch (err) {
    next(err);
  }
};
