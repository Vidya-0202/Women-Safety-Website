const NGO = require('../models/NGO');

// ── GET /api/ngos ─────────────────────────────────────
// Query: ?city=pune&service=shelter&search=shakti&page=1&limit=9
exports.getAllNGOs = async (req, res, next) => {
  try {
    const { city, service, search, page = 1, limit = 9 } = req.query;
    const filter = { isActive: true };

    if (city) filter.city = new RegExp(city, 'i');
    if (service) filter.tags = service.toLowerCase();
    if (search) {
      filter.$or = [
        { name: new RegExp(search, 'i') },
        { city: new RegExp(search, 'i') },
        { services: new RegExp(search, 'i') },
      ];
    }

    const total = await NGO.countDocuments(filter);
    const ngos = await NGO.find(filter)
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .sort({ rating: -1 });

    res.status(200).json({
      success: true,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: ngos,
    });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/ngos/nearby ─────────────────────────────
// Query: ?lat=18.52&lng=73.85&radius=10 (km)
exports.getNearbyNGOs = async (req, res, next) => {
  try {
    const { lat, lng, radius = 10 } = req.query;
    if (!lat || !lng) {
      return res.status(400).json({ success: false, message: 'lat and lng are required' });
    }
    const ngos = await NGO.find({
      isActive: true,
      location: {
        $near: {
          $geometry: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
          $maxDistance: radius * 1000, // metres
        },
      },
    }).limit(20);

    res.status(200).json({ success: true, count: ngos.length, data: ngos });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/ngos/:id ─────────────────────────────────
exports.getNGOById = async (req, res, next) => {
  try {
    const ngo = await NGO.findById(req.params.id);
    if (!ngo) return res.status(404).json({ success: false, message: 'NGO not found' });
    res.status(200).json({ success: true, data: ngo });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/ngos  (admin only) ─────────────────────
exports.createNGO = async (req, res, next) => {
  try {
    const ngo = await NGO.create(req.body);
    res.status(201).json({ success: true, data: ngo });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/ngos/:id  (admin or ngo_admin) ──────────
exports.updateNGO = async (req, res, next) => {
  try {
    // NGO admins may only edit their own NGO
    if (req.user.role === 'ngo_admin') {
      if (!req.user.managedNGO || req.user.managedNGO.toString() !== req.params.id) {
        return res.status(403).json({ success: false, message: 'Not authorised to edit this NGO' });
      }
    }
    const ngo = await NGO.findByIdAndUpdate(req.params.id, req.body, {
      new: true, runValidators: true,
    });
    if (!ngo) return res.status(404).json({ success: false, message: 'NGO not found' });
    res.status(200).json({ success: true, data: ngo });
  } catch (err) {
    next(err);
  }
};

// ── DELETE /api/ngos/:id  (admin only) ───────────────
exports.deleteNGO = async (req, res, next) => {
  try {
    const ngo = await NGO.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
    if (!ngo) return res.status(404).json({ success: false, message: 'NGO not found' });
    res.status(200).json({ success: true, message: 'NGO deactivated' });
  } catch (err) {
    next(err);
  }
};
