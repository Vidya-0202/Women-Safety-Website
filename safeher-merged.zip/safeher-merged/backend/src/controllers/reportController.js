const IncidentReport = require('../models/IncidentReport');
const User = require('../models/User');
const { createNotification } = require('../socket/notifications');

let _io = null;
exports.setIO = (io) => { _io = io; };

// ── POST /api/reports ─────────────────────────────────
exports.createReport = async (req, res, next) => {
  try {
    const { type, incidentDate, location, coordinates, description, contactInfo } = req.body;

    const evidence = (req.files || []).map((f) => ({
      filename: f.filename,
      originalName: f.originalname,
      mimetype: f.mimetype,
      size: f.size,
      path: f.path,
    }));

    const report = await IncidentReport.create({
      reporter: req.user?._id || null,
      contactInfo,
      type,
      incidentDate,
      location,
      coordinates,
      description,
      evidence,
      isAnonymous: !req.user,
    });

    // Notify all admins
    const admins = await User.find({ role: 'admin', isActive: true });
    for (const admin of admins) {
      await createNotification(_io, {
        recipient: admin._id,
        type: 'report_received',
        title: '📝 New Incident Report',
        message: `A new ${type} report was filed from ${location}.`,
        link: `/admin/reports/${report._id}`,
        refModel: 'IncidentReport',
        refId: report._id,
      });
    }

    res.status(201).json({ success: true, data: report });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/reports  (admin/ngo_admin) ───────────────
exports.getAllReports = async (req, res, next) => {
  try {
    const { status, type, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (type) filter.type = type;

    const total = await IncidentReport.countDocuments(filter);
    const reports = await IncidentReport.find(filter)
      .populate('reporter', 'name email')
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, total, data: reports });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/reports/my  (user's own) ─────────────────
exports.getMyReports = async (req, res, next) => {
  try {
    const reports = await IncidentReport.find({ reporter: req.user._id }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: reports });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/reports/:id ──────────────────────────────
exports.getReportById = async (req, res, next) => {
  try {
    const report = await IncidentReport.findById(req.params.id)
      .populate('reporter', 'name email')
      .populate('adminNotes.addedBy', 'name');

    if (!report) return res.status(404).json({ success: false, message: 'Report not found' });

    if (req.user.role === 'user' && report.reporter?.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorised' });
    }

    res.status(200).json({ success: true, data: report });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/reports/:id  (admin) ─────────────────────
exports.updateReport = async (req, res, next) => {
  try {
    const { status, adminNote, forwardedToPolice } = req.body;
    const report = await IncidentReport.findById(req.params.id);
    if (!report) return res.status(404).json({ success: false, message: 'Report not found' });

    if (status) report.status = status;
    if (adminNote) report.adminNotes.push({ text: adminNote, addedBy: req.user._id });
    if (forwardedToPolice !== undefined) {
      report.forwardedToPolice = forwardedToPolice;
      if (forwardedToPolice) report.forwardedAt = new Date();
    }
    await report.save();

    // Notify reporter if not anonymous
    if (report.reporter) {
      await createNotification(_io, {
        recipient: report.reporter,
        type: 'report_updated',
        title: '📋 Report Status Updated',
        message: `Your incident report status changed to: ${report.status}.`,
        link: `/dashboard`,
        refModel: 'IncidentReport',
        refId: report._id,
      });
    }

    res.status(200).json({ success: true, data: report });
  } catch (err) {
    next(err);
  }
};
