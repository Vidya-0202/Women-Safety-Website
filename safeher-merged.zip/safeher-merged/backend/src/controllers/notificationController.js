const Notification = require('../models/Notification');

// ── GET /api/notifications  (my notifications) ────────
exports.getMyNotifications = async (req, res, next) => {
  try {
    const notifications = await Notification.find({ recipient: req.user._id })
      .sort({ createdAt: -1 })
      .limit(50);
    const unreadCount = await Notification.countDocuments({ recipient: req.user._id, isRead: false });
    res.status(200).json({ success: true, unreadCount, data: notifications });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/notifications/:id/read ──────────────────
exports.markAsRead = async (req, res, next) => {
  try {
    await Notification.findOneAndUpdate(
      { _id: req.params.id, recipient: req.user._id },
      { isRead: true }
    );
    res.status(200).json({ success: true });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/notifications/read-all ──────────────────
exports.markAllRead = async (req, res, next) => {
  try {
    await Notification.updateMany({ recipient: req.user._id, isRead: false }, { isRead: true });
    res.status(200).json({ success: true });
  } catch (err) {
    next(err);
  }
};
