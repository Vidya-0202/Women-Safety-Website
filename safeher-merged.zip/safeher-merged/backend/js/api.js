/* ══════════════════════════════════════════
   SafeHer — Frontend API Integration
   Replace the DB object in app.js with this.
   Drop this file in: js/api.js
   Then add <script src="js/api.js"></script>
   BEFORE <script src="js/app.js"></script>
══════════════════════════════════════════ */

const API_BASE = 'http://localhost:5000/api';

// ── Token helpers ────────────────────────────────────
const Auth = {
  getToken: () => localStorage.getItem('safeher_token'),
  setToken: (t) => localStorage.setItem('safeher_token', t),
  removeToken: () => localStorage.removeItem('safeher_token'),
  getUser: () => JSON.parse(localStorage.getItem('safeher_user') || 'null'),
  setUser: (u) => localStorage.setItem('safeher_user', JSON.stringify(u)),
  removeUser: () => localStorage.removeItem('safeher_user'),
  isLoggedIn: () => !!localStorage.getItem('safeher_token'),
};

// ── Base fetch wrapper ───────────────────────────────
async function apiFetch(endpoint, options = {}) {
  const token = Auth.getToken();
  const headers = { 'Content-Type': 'application/json', ...options.headers };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.message || 'Something went wrong');
  }
  return data;
}

// ── Form data fetch (for file uploads) ──────────────
async function apiFormFetch(endpoint, formData) {
  const token = Auth.getToken();
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: 'POST',
    headers,
    body: formData,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Upload failed');
  return data;
}

// ══════════════════════════════════════════
//  AUTH API
// ══════════════════════════════════════════
const AuthAPI = {
  async register(name, email, phone, password) {
    const data = await apiFetch('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, phone, password }),
    });
    Auth.setToken(data.token);
    Auth.setUser(data.data.user);
    return data.data.user;
  },

  async login(email, password) {
    const data = await apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    Auth.setToken(data.token);
    Auth.setUser(data.data.user);
    return data.data.user;
  },

  logout() {
    Auth.removeToken();
    Auth.removeUser();
    // Disconnect socket
    if (window._socket) window._socket.disconnect();
    toast('Logged out successfully', 'success');
    showPage('home');
  },

  async getMe() {
    const data = await apiFetch('/auth/me');
    Auth.setUser(data.data.user);
    return data.data.user;
  },

  async updateMe(updates) {
    const data = await apiFetch('/auth/me', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
    Auth.setUser(data.data.user);
    return data.data.user;
  },

  async changePassword(currentPassword, newPassword) {
    return apiFetch('/auth/change-password', {
      method: 'PUT',
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  },
};

// ══════════════════════════════════════════
//  NGO API
// ══════════════════════════════════════════
const NGOAPI = {
  async getAll(params = {}) {
    const q = new URLSearchParams(params).toString();
    return apiFetch(`/ngos?${q}`);
  },

  async getNearby(lat, lng, radius = 10) {
    return apiFetch(`/ngos/nearby?lat=${lat}&lng=${lng}&radius=${radius}`);
  },

  async getById(id) {
    return apiFetch(`/ngos/${id}`);
  },
};

// ══════════════════════════════════════════
//  HELP REQUESTS API
// ══════════════════════════════════════════
const HelpAPI = {
  async submit(formData) {
    return apiFetch('/help-requests', {
      method: 'POST',
      body: JSON.stringify(formData),
    });
  },

  async getMy() {
    return apiFetch('/help-requests/my');
  },

  async getById(id) {
    return apiFetch(`/help-requests/${id}`);
  },
};

// ══════════════════════════════════════════
//  REPORTS API
// ══════════════════════════════════════════
const ReportAPI = {
  async submit(formData, files) {
    // Use multipart form data so files can be attached
    const fd = new FormData();
    Object.entries(formData).forEach(([k, v]) => fd.append(k, v));
    if (files) {
      Array.from(files).forEach((f) => fd.append('evidence', f));
    }
    return apiFormFetch('/reports', fd);
  },

  async getMy() {
    return apiFetch('/reports/my');
  },
};

// ══════════════════════════════════════════
//  NOTIFICATIONS API
// ══════════════════════════════════════════
const NotifAPI = {
  async getMy() {
    return apiFetch('/notifications');
  },

  async markRead(id) {
    return apiFetch(`/notifications/${id}/read`, { method: 'PUT' });
  },

  async markAllRead() {
    return apiFetch('/notifications/read-all', { method: 'PUT' });
  },
};

// ══════════════════════════════════════════
//  REAL-TIME SOCKET.IO
// ══════════════════════════════════════════
function connectSocket() {
  if (!Auth.isLoggedIn()) return;
  if (window._socket?.connected) return;

  // Dynamically load socket.io client from server
  const script = document.createElement('script');
  script.src = 'http://localhost:5000/socket.io/socket.io.js';
  script.onload = () => {
    const socket = io('http://localhost:5000', {
      auth: { token: Auth.getToken() },
    });
    window._socket = socket;

    socket.on('connect', () => {
      console.log('🔌 Real-time connected');
    });

    // New notification received
    socket.on('notification', (notif) => {
      showNotificationBadge();
      toast(`${notif.title}: ${notif.message}`, 'info');
    });

    // SOS alert (for admin/NGO users)
    socket.on('sos_alert', (data) => {
      toast(`🆘 SOS ALERT from ${data.userName} — ${data.lat}, ${data.lng}`, 'error');
    });

    socket.on('disconnect', () => console.log('🔌 Socket disconnected'));
  };
  document.head.appendChild(script);
}

// Emit SOS via socket (in addition to modal)
function emitSOS(lat, lng) {
  if (window._socket?.connected) {
    window._socket.emit('sos_alert', { lat, lng });
  }
}

// Show unread badge on nav (simple implementation)
async function showNotificationBadge() {
  if (!Auth.isLoggedIn()) return;
  try {
    const { unreadCount } = await NotifAPI.getMy();
    const badge = document.getElementById('notif-badge');
    if (badge) {
      badge.textContent = unreadCount;
      badge.style.display = unreadCount > 0 ? 'flex' : 'none';
    }
  } catch {}
}

// ══════════════════════════════════════════
//  OVERRIDE app.js FUNCTIONS
//  These replace the localStorage-based
//  versions when this file is loaded first.
// ══════════════════════════════════════════

// Override submitHelp to use API
window.submitHelp = async function (e) {
  e.preventDefault();
  const btn = e.target.querySelector('[type=submit]');
  btn.textContent = 'Submitting…';
  btn.disabled = true;

  try {
    await HelpAPI.submit({
      name: document.getElementById('help-name').value || 'Anonymous',
      contact: document.getElementById('help-contact').value,
      type: document.getElementById('help-type').value,
      description: document.getElementById('help-desc').value,
      location: document.getElementById('help-location').value,
      preferredContactTime: document.getElementById('help-time').value,
    });
    e.target.reset();
    toast('✅ Help request submitted! An NGO will contact you within 30 minutes.', 'success');
    showPage('dashboard');
  } catch (err) {
    toast(err.message || 'Submission failed. Please try again.', 'error');
  } finally {
    btn.textContent = 'Submit Help Request 🤝';
    btn.disabled = false;
  }
};

// Override submitReport to use API
window.submitReport = async function (e) {
  e.preventDefault();
  const btn = e.target.querySelector('[type=submit]');
  btn.textContent = 'Submitting…';
  btn.disabled = true;

  try {
    const files = document.getElementById('file-input').files;
    await ReportAPI.submit(
      {
        type: document.getElementById('report-type').value,
        incidentDate: document.getElementById('report-date').value,
        location: document.getElementById('report-location').value,
        description: document.getElementById('report-desc').value,
        contactInfo: document.getElementById('report-contact').value,
      },
      files
    );
    e.target.reset();
    document.getElementById('file-preview').classList.add('hidden');
    toast('📝 Incident reported successfully. Our team will review it.', 'success');
  } catch (err) {
    toast(err.message || 'Report submission failed.', 'error');
  } finally {
    btn.textContent = 'Submit Report 📝';
    btn.disabled = false;
  }
};

// Override refreshDashboard to pull from API
window.refreshDashboard = async function () {
  if (!Auth.isLoggedIn()) {
    // Show login prompt if not logged in
    document.getElementById('dash-requests-count').textContent = '—';
    document.getElementById('dash-reports-count').textContent = '—';
    document.getElementById('dash-contacts-count').textContent = '—';
    return;
  }
  try {
    const [requestsData, reportsData, userData] = await Promise.all([
      HelpAPI.getMy(),
      ReportAPI.getMy(),
      AuthAPI.getMe(),
    ]);
    const requests = requestsData.data;
    const reports = reportsData.data;
    const user = userData;

    document.getElementById('dash-requests-count').textContent = requests.length;
    document.getElementById('dash-reports-count').textContent = reports.length;
    document.getElementById('dash-contacts-count').textContent = user.emergencyContacts?.length || 0;

    // Requests list
    const reqList = document.getElementById('dash-requests-list');
    if (requests.length === 0) {
      reqList.innerHTML = '<p style="color:var(--ink-muted);text-align:center;padding:24px;">No help requests yet. <a onclick="showPage(\'help\')" style="color:var(--rose);cursor:pointer;">Submit one →</a></p>';
    } else {
      reqList.innerHTML = requests.map(r => `
        <div class="request-status-row">
          <div>
            <div class="fw-600 fs-sm color-ink">${r.type}</div>
            <div class="fs-sm" style="color:var(--ink-muted);">${new Date(r.createdAt).toLocaleDateString()} · ${r.location}</div>
            ${r.assignedNGO ? `<div class="fs-sm" style="color:var(--plum);">Assigned: ${r.assignedNGO.name}</div>` : ''}
          </div>
          <span class="status-pill ${r.status === 'Pending' ? 'status-pending' : r.status === 'Active' || r.status === 'Assigned' ? 'status-active' : 'status-closed'}">${r.status}</span>
        </div>`).join('');
    }

    // Reports list
    const repList = document.getElementById('dash-reports-list');
    if (reports.length === 0) {
      repList.innerHTML = '<p style="color:var(--ink-muted);text-align:center;padding:24px;">No reports yet. <a onclick="showPage(\'report\')" style="color:var(--rose);cursor:pointer;">Report an incident →</a></p>';
    } else {
      repList.innerHTML = reports.map(r => `
        <div class="request-status-row">
          <div>
            <div class="fw-600 fs-sm color-ink">${r.type}</div>
            <div class="fs-sm" style="color:var(--ink-muted);">${new Date(r.incidentDate).toLocaleDateString()} · ${r.location}</div>
          </div>
          <span class="status-pill status-pending">${r.status}</span>
        </div>`).join('');
    }

    // Emergency contacts from user profile
    const conList = document.getElementById('dash-contacts-list');
    const contacts = user.emergencyContacts || [];
    if (contacts.length === 0) {
      conList.innerHTML = '<p style="color:var(--ink-muted);text-align:center;padding:12px;">No emergency contacts added yet.</p>';
    } else {
      conList.innerHTML = contacts.map(c => `
        <div class="ec-row">
          <div class="ec-avatar">👤</div>
          <div>
            <div class="fw-600 fs-sm color-ink">${c.name}</div>
            <div class="fs-sm" style="color:var(--ink-muted);">${c.relation} · ${c.phone}</div>
          </div>
          <a href="tel:${c.phone.replace(/\s/g, '')}" class="btn btn-primary btn-sm ec-call">📞 Call</a>
        </div>`).join('');
    }
  } catch (err) {
    toast('Could not load dashboard data: ' + err.message, 'error');
  }
};

// Override addEmergencyContact to persist to API
window.addEmergencyContact = async function () {
  const name = prompt('Contact Name:');
  if (!name) return;
  const phone = prompt('Phone Number:');
  if (!phone) return;
  const relation = prompt('Relation (e.g. Sister, Friend):') || 'Contact';

  try {
    const user = Auth.getUser();
    const contacts = [...(user.emergencyContacts || []), { name, phone, relation }];
    await AuthAPI.updateMe({ emergencyContacts: contacts });
    refreshDashboard();
    toast(`${name} added to emergency contacts!`, 'success');
  } catch (err) {
    toast('Could not save contact: ' + err.message, 'error');
  }
};

// Override NGO directory render to use API
window.renderDirectory = async function () {
  const grid = document.getElementById('directory-grid');
  grid.innerHTML = '<div style="text-align:center;padding:40px;color:var(--ink-muted);">Loading NGOs…</div>';

  try {
    const search = document.getElementById('ngo-search')?.value || '';
    const params = { limit: 9 };
    if (search) params.search = search;
    if (currentFilter !== 'all') params.service = currentFilter;

    const { data, total } = await NGOAPI.getAll(params);
    document.getElementById('ngo-count').textContent = total;

    if (data.length === 0) {
      grid.innerHTML = '';
      document.getElementById('no-results').classList.remove('hidden');
      return;
    }
    document.getElementById('no-results').classList.add('hidden');
    grid.innerHTML = data.map(renderNGOCard).join('');
  } catch (err) {
    grid.innerHTML = `<div style="text-align:center;padding:40px;color:var(--rose);">Failed to load NGOs: ${err.message}</div>`;
  }
};

// Init: connect socket on page load if already logged in
document.addEventListener('DOMContentLoaded', () => {
  if (Auth.isLoggedIn()) {
    connectSocket();
    showNotificationBadge();
  }
});
