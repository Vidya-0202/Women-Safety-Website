# 🌸 SafeHer — Backend API

Node.js + Express + MongoDB backend for the SafeHer Women Safety Platform.

---

## 📁 Project Structure

```
safeher-backend/
├── config/
│   └── db.js                  # MongoDB connection
├── src/
│   ├── server.js              # Entry point, Express + Socket.IO setup
│   ├── seed.js                # Database seeder
│   ├── models/
│   │   ├── User.js            # User (user / ngo_admin / admin)
│   │   ├── NGO.js             # NGO organisations
│   │   ├── HelpRequest.js     # Help requests from women
│   │   ├── IncidentReport.js  # Incident reports
│   │   └── Notification.js    # In-app notifications
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── ngoController.js
│   │   ├── helpRequestController.js
│   │   ├── reportController.js
│   │   ├── notificationController.js
│   │   └── adminController.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── ngos.js
│   │   ├── helpRequests.js
│   │   ├── reports.js
│   │   ├── notifications.js
│   │   └── admin.js
│   ├── middleware/
│   │   ├── auth.js            # JWT protect + role authorise
│   │   ├── errorHandler.js    # Global error handler
│   │   └── upload.js          # Multer file uploads
│   └── socket/
│       └── notifications.js   # Real-time notification helper
└── js/
    └── api.js                 # Drop into SafeHer frontend
```

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
cd safeher-backend
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your MongoDB URI and secrets
```

### 3. Start MongoDB
```bash
# Local MongoDB
mongod

# Or use MongoDB Atlas — paste your connection string in .env
```

### 4. Seed the database
```bash
npm run seed
```

This creates:
| Role       | Email                    | Password      |
|------------|--------------------------|---------------|
| Admin      | admin@safeher.org        | Admin@123456  |
| NGO Admin  | ngo@nirbhayasena.org     | Ngo@123456    |
| User       | user@safeher.org         | User@123456   |

### 5. Start the server
```bash
npm run dev      # development (auto-restart)
npm start        # production
```

Server runs at: **http://localhost:5000**

---

## 🔗 API Reference

### Auth
| Method | Endpoint                    | Access  | Description              |
|--------|-----------------------------|---------|--------------------------|
| POST   | /api/auth/register          | Public  | Register new user        |
| POST   | /api/auth/login             | Public  | Login, returns JWT       |
| GET    | /api/auth/me                | User    | Get logged-in user       |
| PUT    | /api/auth/me                | User    | Update profile / contacts|
| PUT    | /api/auth/change-password   | User    | Change password          |

### NGOs
| Method | Endpoint              | Access       | Description              |
|--------|-----------------------|--------------|--------------------------|
| GET    | /api/ngos             | Public       | List all NGOs (paginated)|
| GET    | /api/ngos/nearby      | Public       | NGOs near lat/lng        |
| GET    | /api/ngos/:id         | Public       | Single NGO details       |
| POST   | /api/ngos             | Admin        | Create NGO               |
| PUT    | /api/ngos/:id         | Admin/NGOAdmin | Update NGO             |
| DELETE | /api/ngos/:id         | Admin        | Deactivate NGO           |

### Help Requests
| Method | Endpoint                  | Access       | Description              |
|--------|---------------------------|--------------|--------------------------|
| POST   | /api/help-requests        | Public/User  | Submit help request      |
| GET    | /api/help-requests        | Admin/NGO    | All requests             |
| GET    | /api/help-requests/my     | User         | User's own requests      |
| GET    | /api/help-requests/:id    | User/Admin   | Single request           |
| PUT    | /api/help-requests/:id    | Admin/NGO    | Update status/assign     |
| DELETE | /api/help-requests/:id    | Admin        | Delete request           |

### Reports
| Method | Endpoint              | Access       | Description              |
|--------|-----------------------|--------------|--------------------------|
| POST   | /api/reports          | Public/User  | Submit incident report   |
| GET    | /api/reports          | Admin/NGO    | All reports              |
| GET    | /api/reports/my       | User         | User's own reports       |
| GET    | /api/reports/:id      | User/Admin   | Single report            |
| PUT    | /api/reports/:id      | Admin/NGO    | Update status/add note   |

### Notifications
| Method | Endpoint                        | Access | Description        |
|--------|---------------------------------|--------|--------------------|
| GET    | /api/notifications              | User   | My notifications   |
| PUT    | /api/notifications/:id/read     | User   | Mark one as read   |
| PUT    | /api/notifications/read-all     | User   | Mark all as read   |

### Admin
| Method | Endpoint                          | Access | Description         |
|--------|-----------------------------------|--------|---------------------|
| GET    | /api/admin/stats                  | Admin  | Dashboard stats     |
| GET    | /api/admin/users                  | Admin  | All users           |
| PUT    | /api/admin/users/:id/role         | Admin  | Change user role    |
| PUT    | /api/admin/users/:id/toggle       | Admin  | Activate/deactivate |
| GET    | /api/admin/requests/summary       | Admin  | Requests by status  |

---

## ⚡ Real-Time Events (Socket.IO)

Connect from the frontend:
```js
const socket = io('http://localhost:5000', {
  auth: { token: 'YOUR_JWT_TOKEN' }
});
```

### Client listens for:
| Event          | Payload                                      | Sent when                          |
|----------------|----------------------------------------------|------------------------------------|
| `notification` | `{ title, message, type, link, createdAt }`  | Any new notification for the user  |
| `sos_alert`    | `{ userName, lat, lng, timestamp }`          | User fires SOS (sent to admins)    |

### Client emits:
| Event       | Payload             | Purpose                          |
|-------------|---------------------|----------------------------------|
| `sos_alert` | `{ lat, lng }`      | Trigger SOS — notifies all admins|

---

## 🔐 Authentication

All protected routes require:
```
Authorization: Bearer <JWT_TOKEN>
```

**Roles:**
- `user` — Regular user (submit requests, view own data)
- `ngo_admin` — Manages one NGO (view/update assigned requests)
- `admin` — Full access to everything

---

## 🖥️ Connecting the Frontend

1. Copy `js/api.js` into your SafeHer frontend `js/` folder.
2. In `index.html`, add this **before** `app.js`:
```html
<script src="js/api.js"></script>
<script src="js/app.js"></script>
```
3. That's it — `api.js` overrides the `localStorage`-based functions
   with real API calls automatically.

---

## 🌐 Deployment

### Deploy to Railway / Render
1. Push to GitHub
2. Connect repo on Railway or Render
3. Set environment variables from `.env.example`
4. Use MongoDB Atlas for the database

### Environment variables needed in production:
```
MONGO_URI=mongodb+srv://...
JWT_SECRET=<strong-random-secret>
NODE_ENV=production
CLIENT_URL=https://your-frontend-domain.com
PORT=5000
```

---

## 🛡️ Security Features

- ✅ Passwords hashed with bcrypt (cost factor 12)
- ✅ JWT authentication with expiry
- ✅ Rate limiting (100 req/15min globally, 10 req/15min on auth)
- ✅ Helmet.js security headers
- ✅ CORS restricted to frontend origin
- ✅ Role-based access control (user / ngo_admin / admin)
- ✅ File upload validation (type + size limits)
- ✅ Input sanitisation via mongoose validators
